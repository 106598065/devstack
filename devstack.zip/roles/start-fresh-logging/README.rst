Restart logging on all hosts

Restart syslog so that the system logs only include output from the
job.

**Role Variables**

.. zuul:rolevar:: devstack_base_dir
   :default: /opt/stack

   The devstack base directory.
